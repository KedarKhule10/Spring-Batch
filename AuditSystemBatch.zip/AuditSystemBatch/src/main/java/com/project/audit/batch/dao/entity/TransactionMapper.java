package com.project.audit.batch.dao.entity;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class TransactionMapper implements RowMapper<Transaction> {

    @Override
    public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
        Transaction transaction = new Transaction();
        
        // Mapping fields from ResultSet to Transaction object
        transaction.setTransactionIdPk(rs.getInt("TRANSACTION_ID_PK"));
        transaction.setAccountNumber(rs.getInt("ACCOUNT_NUMBER"));
        transaction.setTransactionId(rs.getString("TRANSACTION_ID"));
        transaction.setTransactionType(rs.getString("TRANSACTION_TYPE"));
        transaction.setAmount(rs.getBigDecimal("AMOUNT"));
        transaction.setTransactionEntryDate(rs.getTimestamp("TRANSACTION_ENTRY_DATE").toLocalDateTime());
        //transaction.setStatus(rs.getString("STATUS"));

        return transaction;
    }
}
