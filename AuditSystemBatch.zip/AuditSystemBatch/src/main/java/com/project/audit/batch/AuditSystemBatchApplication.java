package com.project.audit.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration;

@SpringBootApplication(exclude = { BatchAutoConfiguration.class })
public class AuditSystemBatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuditSystemBatchApplication.class, args);
    }
}
