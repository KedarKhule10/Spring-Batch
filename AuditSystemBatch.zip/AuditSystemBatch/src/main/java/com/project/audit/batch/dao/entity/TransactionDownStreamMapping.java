package com.project.audit.batch.dao.entity;

import java.math.BigInteger;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="TRANSACTION_VIEW")
public class TransactionDownStreamMapping {

	@Id
	@Column(name="TRANSACTION_ID_PK", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transactionIdPk;
	
	@Column(name="ACCOUNT_NUMBER", nullable = false)
	private Integer accountNumber;
	
	@Column(name="TRANSACTION_ID", nullable = false)
	private String transactionId;
	
	@Column(name="TRANSACTION_TYPE", nullable = false)
	private String transactionType;
	
	@Column(name="AMOUNT", nullable = false)
	private BigInteger amount;
	
    @Column(name = "TransactionEntryDate", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime transactionEntryDate;

	public Integer getTransactionIdPk() {
		return transactionIdPk;
	}

	public void setTransactionIdPk(Integer transactionIdPk) {
		this.transactionIdPk = transactionIdPk;
	}

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public BigInteger getAmount() {
		return amount;
	}

	public void setAmount(BigInteger amount) {
		this.amount = amount;
	}

	public LocalDateTime getTransactionEntryDate() {
		return transactionEntryDate;
	}

	public void setTransactionEntryDate(LocalDateTime transactionEntryDate) {
		this.transactionEntryDate = transactionEntryDate;
	}
    
}
