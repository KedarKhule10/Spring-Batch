package com.project.audit.batch.partitioner;

import java.math.BigInteger;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class AuditBatchPartitioner implements Partitioner {

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	private StepExecution stepExecution;
	
	private String totalCountQuery;
	
	private String partitionerCountQuery;
	
	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {
		
		System.out.println("AuditBatchPartitioner.partition()");
		
		Map<String, ExecutionContext> result = new HashMap<String, ExecutionContext>();

		Map<String, Object> count = namedParameterJdbcTemplate.queryForMap(totalCountQuery, new MapSqlParameterSource()
				.addValue("records", 5));
		
		Collection<StepExecution> stepExecutions = stepExecution.getJobExecution().getStepExecutions();
		
		for (StepExecution stepExecution : stepExecutions) {
			System.out.println("Step: "+stepExecution);
		}
		
		Long recordCount = (Long) count.get("TOTAL_COUNT");
		
		int totalCount = recordCount.intValue();
		
		if(totalCount > 0) {

			//make it 1000
			//grid-size = 6
			//commit-interval = 50
			
			
			int range = totalCount / gridSize;
			
			int num = totalCount % gridSize;
			
			int fromId = 1;
			int toId = range;
			
			for (int i = 1; i <= gridSize; i++) {
				
				if(i == gridSize) {
					toId += num;
				}
				
				ExecutionContext executionContext = new ExecutionContext();
				
				System.out.println("Starting : Thread: " + i +" fromId : " + fromId + " toId : " + toId);
				
				List<Map<String,Object>> resultList = namedParameterJdbcTemplate.queryForList(partitionerCountQuery, new MapSqlParameterSource()
						.addValue("fromId", fromId)
						.addValue("toId", toId));
				
				
				executionContext.put("MIN_TRANSACTION_ID", resultList.get(0).get("ID"));
				executionContext.put("MAX_TRANSACTION_ID", resultList.get(1).get("ID"));
				
				
				
				// give each thread a name
				executionContext.put("THREAD", "THREAD"+ "_" + i);
				
				result.put("Partitoner" + i, executionContext);
				
				fromId = toId + 1;
				toId = fromId  + range - 1;
				
			}
		}

		return result;
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}

	public void setTotalCountQuery(String totalCountQuery) {
		this.totalCountQuery = totalCountQuery;
	}

	public String getPartitionerCountQuery() {
		return partitionerCountQuery;
	}

	public void setPartitionerCountQuery(String partitionerCountQuery) {
		this.partitionerCountQuery = partitionerCountQuery;
	}

}
