package com.project.audit.batch.writer;

import java.util.List;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemStreamWriter;
import org.springframework.batch.item.ItemWriter;
import org.springframework.transaction.annotation.Transactional;
import com.project.audit.batch.dao.entity.Transaction;

public class AuditDownstreamDataWriter implements ItemWriter<List<Object>> {

	@Override
	@Transactional
	public void write(Chunk<? extends List<Object>> items) throws Exception {
        System.out.println("AuditDownstreamDataWriter.write()");
        Transaction transaction = null;
        
        // Iterate through each object in the list
        if(items != null && !items.isEmpty()) {
        	List<Object> list = items.getItems().get(0);
            for (Object object : list) {
                if (object instanceof Transaction) {
                    transaction = (Transaction) object;
                    
//                    System.out.println("Transaction Id Pk: " + transaction.getTransactionIdPk());
//                    System.out.println("Amount: " + transaction.getAmount());
//                    System.out.println("Transaction Type: " + transaction.getTransactionType());
//                    System.out.println("Transaction Id: " + transaction.getTransactionId());
                    
                    
                } else {
                    System.out.println("Unrecognized object: " + object.getClass().getName());
                }
            }
        	
        }
	}
}
