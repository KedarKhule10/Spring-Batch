package com.project.audit.batch.exception;

public class CustomException extends Exception {

}
