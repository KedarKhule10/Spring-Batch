package com.project.audit.batch.reader;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcPagingItemReader;

import com.project.audit.batch.dao.entity.Transaction;

public class AuditDownstreamDataReader implements ItemReader<List<Transaction>>{

	private JdbcPagingItemReader<Transaction> auditReader;
	
	@Override
	public List<Transaction> read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		List<Transaction> transactionList = new ArrayList<>();
		//Transaction read = (Transaction) auditReader.read();
		
		while(process(auditReader.read(),transactionList)) {
			continue;
		}
		
		if(!transactionList.isEmpty()) {
			return transactionList;
		}
		
		return null;
	}

	private boolean process(Transaction transaction, List<Transaction> transactionList) {
		
		if(transaction != null) {
			transactionList.add(transaction);
		}
		
		if(transaction == null) {
			return false;
		}
		
		
		return true;
	}

	public void setAuditReader(JdbcPagingItemReader<Transaction> auditReader) {
		this.auditReader = auditReader;
	}
	
}
