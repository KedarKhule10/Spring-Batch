package com.project.audit.batch.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/invoke")
public class BatchController {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job auditBatchJob;

    @GetMapping("/auditBatch")
    public void invokeBatch(@RequestParam String jobName) throws Exception {
       JobParameters jobParameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .addString("jobName", jobName)
                .toJobParameters();

       JobExecution jobExecution = jobLauncher.run(auditBatchJob, jobParameters);
        
        
        System.out.println("Exit Status: " +  jobExecution.getExitStatus().getExitCode());
    }
}