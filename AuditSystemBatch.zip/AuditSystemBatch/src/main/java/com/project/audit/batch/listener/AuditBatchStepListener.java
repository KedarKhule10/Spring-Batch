package com.project.audit.batch.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ExecutionContext;

public class AuditBatchStepListener implements StepExecutionListener{

	private StepExecution stepExecution;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
		ExecutionContext executionContext = stepExecution.getExecutionContext();
		System.out.println("AuditBatchStepListener.beforeStep()");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
		
		System.out.println("AuditBatchStepListener.afterStep()");
		
		return stepExecution.getExitStatus();
	}

}
