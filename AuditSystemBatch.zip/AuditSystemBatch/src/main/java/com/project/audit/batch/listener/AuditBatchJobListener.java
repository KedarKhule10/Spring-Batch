package com.project.audit.batch.listener;

import java.util.Collection;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;

public class AuditBatchJobListener implements JobExecutionListener{

	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println("AuditBatchJobListener.beforeJob()");
		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println("AuditBatchJobListener.afterJob()");
	}
}
